'use client';

import React, { createContext, useContext, useEffect, useState, useCallback, ReactNode } from 'react';
import { useRouter } from 'next/navigation';
import { UserProfile, AuthState, AuthResult } from '@/types/auth';
import { UserRole, normalizeRole } from '@/types/roles';
import { Tables } from '@/types/database';
import { getSupabaseBrowserClient } from '@/lib/supabase/client';

interface AuthContextType extends AuthState {
  signIn: (email: string, password: string) => Promise<AuthResult>;
  signOut: () => Promise<void>;
  resetPassword: (email: string) => Promise<{ success: boolean; message: string }>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const ROLE_COOKIE_KEY = 'campusnexus_active_role';
const AUTH_COOKIE_KEY = 'campusnexus_authenticated';

function setCookie(name: string, value: string, days = 7) {
  if (typeof document === 'undefined') return;
  const expires = new Date(Date.now() + days * 864e5).toUTCString();
  document.cookie = `${name}=${encodeURIComponent(value)}; expires=${expires}; path=/; SameSite=Lax`;
}

function deleteCookie(name: string) {
  if (typeof document === 'undefined') return;
  document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; SameSite=Lax`;
}

function createMockProfile(email: string): UserProfile {
  const normalized = email.toLowerCase().trim();
  
  // Determine role
  let role: UserRole = 'student';
  if (normalized.includes('hod')) {
    role = 'hod';
  } else if (normalized.includes('faculty') || normalized.includes('prof') || normalized.includes('teacher')) {
    role = 'faculty';
  }

  // Determine department
  let dept = 'IT';
  if (normalized.includes('cse')) dept = 'CSE';
  else if (normalized.includes('ece')) dept = 'ECE';
  else if (normalized.includes('eee')) dept = 'EEE';
  else if (normalized.includes('mech')) dept = 'MECH';
  else if (normalized.includes('civil')) dept = 'CIVIL';

  if (role === 'hod') {
    return {
      id: 'demo-hod-id',
      email: normalized,
      fullName: `Dr. David Vance, Ph.D. (${dept} HOD)`,
      role: 'hod',
      department: dept,
      phone: '+91 98765 43210',
      isActive: true,
      profileCompletion: 100,
      designation: 'Head of Department & Senior Professor',
      specialization: 'Distributed Systems & Cloud Computing',
      qualification: 'Ph.D. in Computer Science',
      experienceYears: 18,
      officeLocation: 'Block 2, Room 401',
      officeHours: 'Mon-Fri 10:00 AM - 1:00 PM',
    };
  }

  if (role === 'faculty') {
    return {
      id: 'demo-faculty-id',
      email: normalized,
      fullName: `Dr. Sarah Jenkins (${dept} Faculty)`,
      role: 'faculty',
      department: dept,
      phone: '+91 98765 12345',
      isActive: true,
      profileCompletion: 95,
      facultyId: `${dept}-FAC-014`,
      designation: 'Associate Professor',
      specialization: 'Artificial Intelligence & Machine Learning',
      qualification: 'Ph.D. in Information Technology',
      experienceYears: 9,
      teachingSubjects: ['Machine Learning', 'Data Structures', 'Cloud Computing'],
      officeLocation: 'Block 2, Room 304',
      officeHours: 'Mon-Wed 2:00 PM - 4:00 PM',
    };
  }

  // Student
  return {
    id: 'demo-student-id',
    email: normalized,
    fullName: `Alex Chen (${dept} Student)`,
    role: 'student',
    department: dept,
    studentId: `22${dept}042`,
    year: 3,
    semester: 6,
    section: 'A',
    branch: dept,
    batch: '2022-2026',
    admissionYear: 2022,
    cgpa: 8.85,
    attendancePct: 92,
    backlogCount: 0,
    phone: '+91 98765 67890',
    isActive: true,
    profileCompletion: 88,
    careerGoalTitle: 'Full-Stack Distributed Systems Engineer',
    careerDomain: 'Full-Stack & Cloud Computing',
    preferredRole: 'Software Development Engineer (SDE-1)',
    internshipStatus: 'Applied',
    placementStatus: 'Eligible',
    higherStudies: false,
    githubUrl: 'https://github.com/alexchen',
    linkedinUrl: 'https://linkedin.com/in/alexchen',
    portfolioUrl: 'https://alexchen.dev',
    resumeUrl: 'https://drive.google.com/file/sample-resume/view',
    bio: 'Third-year engineering student passionate about distributed systems, Next.js, and cloud backends.',
  };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const router = useRouter();
  const [user, setUser] = useState<UserProfile | null>(null);
  const [role, setRole] = useState<UserRole | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch complete profile from Supabase Database (profiles + students/faculty child records)
  const fetchUserProfile = useCallback(async (userId: string, userEmail: string): Promise<UserProfile | null> => {
    try {
      const supabase = getSupabaseBrowserClient();

      // 1. Fetch base profile
      const { data, error: profileErr } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .maybeSingle();

      if (profileErr) {
        console.error('Error querying profiles table:', profileErr);
        return null;
      }

      if (!data) {
        return null;
      }

      const profileData = data as Tables<'profiles'>;
      const userRole = normalizeRole(profileData.role) || 'student';

      // 2. Fetch role-specific child extension record
      let studentRecord: Tables<'students'> | null = null;
      let facultyRecord: Tables<'faculty'> | null = null;

      if (userRole === 'student') {
        const { data: sData } = await supabase
          .from('students')
          .select('*')
          .eq('id', userId)
          .maybeSingle();
        studentRecord = sData ? (sData as Tables<'students'>) : null;
      } else if (userRole === 'faculty' || userRole === 'hod') {
        const { data: fData } = await supabase
          .from('faculty')
          .select('*')
          .eq('id', userId)
          .maybeSingle();
        facultyRecord = fData ? (fData as Tables<'faculty'>) : null;
      }

      return {
        // Core identity
        id: profileData.id,
        email: profileData.email || userEmail,
        fullName: profileData.full_name,
        role: userRole,
        department: profileData.department || 'IT',
        avatarUrl: profileData.avatar_url,
        phone: profileData.phone,
        isActive: profileData.is_active,
        profileCompletion: profileData.profile_completion ?? 0,
        createdAt: profileData.created_at,
        updatedAt: profileData.updated_at,

        // Student fields
        ...(studentRecord ? {
          studentId: studentRecord.roll_number,
          year: studentRecord.year,
          semester: studentRecord.semester,
          section: studentRecord.section,
          branch: studentRecord.branch,
          batch: studentRecord.batch,
          admissionYear: studentRecord.admission_year,
          cgpa: studentRecord.cgpa,
          attendancePct: studentRecord.attendance_pct,
          backlogCount: studentRecord.backlog_count,
          dateOfBirth: studentRecord.date_of_birth,
          gender: studentRecord.gender,
          bio: studentRecord.bio,
          githubUrl: studentRecord.github_url,
          linkedinUrl: studentRecord.linkedin_url,
          portfolioUrl: studentRecord.portfolio_url,
          resumeUrl: studentRecord.resume_url,
          careerGoalTitle: studentRecord.career_goal_title,
          careerDomain: studentRecord.career_domain,
          preferredRole: studentRecord.preferred_role,
          internshipStatus: studentRecord.internship_status,
          placementStatus: studentRecord.placement_status,
          higherStudies: studentRecord.higher_studies,
        } : {}),

        // Faculty/HOD fields
        ...(facultyRecord ? {
          facultyId: facultyRecord.employee_id,
          designation: facultyRecord.designation,
          specialization: facultyRecord.specialization,
          qualification: facultyRecord.qualification,
          experienceYears: facultyRecord.experience_years,
          teachingSubjects: facultyRecord.teaching_subjects,
          skills: facultyRecord.skills,
          profileBio: facultyRecord.profile_bio,
          officeLocation: facultyRecord.office_location,
          officeHours: facultyRecord.office_hours,
        } : {}),
      };
    } catch (err) {
      console.error('Exception fetching user profile:', err);
      return null;
    }
  }, []);

  // Initialize and synchronize Supabase session on app mount
  useEffect(() => {
    let isMounted = true;
    const supabase = getSupabaseBrowserClient();

    async function initSession() {
      try {
        const { data: { session }, error: sessionErr } = await supabase.auth.getSession();

        if (sessionErr) {
          console.warn('Supabase getSession error:', sessionErr.message);
        }

        if (session?.user && isMounted) {
          const profile = await fetchUserProfile(session.user.id, session.user.email || '');

          if (profile) {
            // Check account active status
            if (profile.isActive === false) {
              await supabase.auth.signOut();
              deleteCookie(ROLE_COOKIE_KEY);
              deleteCookie(AUTH_COOKIE_KEY);
              setUser(null);
              setRole(null);
              setError('Your account has been deactivated. Please contact the department.');
            } else {
              setUser(profile);
              setRole(profile.role);
              setCookie(ROLE_COOKIE_KEY, profile.role);
              setCookie(AUTH_COOKIE_KEY, 'true');
            }
          }
        } else if (isMounted) {
          deleteCookie(ROLE_COOKIE_KEY);
          deleteCookie(AUTH_COOKIE_KEY);
          setUser(null);
          setRole(null);
        }
      } catch (err) {
        console.error('Auth initialization error:', err);
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    }

    initSession();

    // Listen to Supabase Auth state changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (!isMounted) return;

      if (event === 'SIGNED_IN' && session?.user) {
        const profile = await fetchUserProfile(session.user.id, session.user.email || '');
        if (profile && profile.isActive !== false) {
          setUser(profile);
          setRole(profile.role);
          setCookie(ROLE_COOKIE_KEY, profile.role);
          setCookie(AUTH_COOKIE_KEY, 'true');
        } else if (profile && profile.isActive === false) {
          await supabase.auth.signOut();
          deleteCookie(ROLE_COOKIE_KEY);
          deleteCookie(AUTH_COOKIE_KEY);
          setUser(null);
          setRole(null);
          setError('Your account has been deactivated. Please contact the department.');
        }
      } else if (event === 'SIGNED_OUT') {
        deleteCookie(ROLE_COOKIE_KEY);
        deleteCookie(AUTH_COOKIE_KEY);
        setUser(null);
        setRole(null);
      }
    });

    return () => {
      isMounted = false;
      subscription.unsubscribe();
    };
  }, [fetchUserProfile]);

  const refreshProfile = useCallback(async () => {
    try {
      const supabase = getSupabaseBrowserClient();
      let targetUserId = user?.id;
      let targetUserEmail = user?.email || '';

      if (!targetUserId) {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.user) {
          targetUserId = session.user.id;
          targetUserEmail = session.user.email || '';
        }
      }

      if (!targetUserId) return;

      const refreshed = await fetchUserProfile(targetUserId, targetUserEmail);
      if (refreshed) {
        setUser(refreshed);
        setRole(refreshed.role);
        setCookie(ROLE_COOKIE_KEY, refreshed.role);
      }
    } catch (e) {
      console.error('Error refreshing profile:', e);
    }
  }, [user, fetchUserProfile]);

  const signIn = useCallback(
    async (email: string, password: string): Promise<AuthResult> => {
      setIsLoading(true);
      setError(null);

      const trimmedEmail = email.trim();
      const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
      const isPlaceholderSupabase = supabaseUrl.includes('demo-itnexus') || !supabaseUrl.startsWith('http');

      try {
        const supabase = getSupabaseBrowserClient();

        // Real Supabase project — use proper authentication
        if (!isPlaceholderSupabase) {
          const { data: authData, error: authErr } = await supabase.auth.signInWithPassword({
            email: trimmedEmail,
            password,
          });

          if (authErr) {
            const errMsg = authErr.message || 'Invalid email or password. Please try again.';
            setError(errMsg);
            setIsLoading(false);
            return { success: false, error: errMsg };
          }

          if (authData.session && authData.user) {
            const profile = await fetchUserProfile(authData.user.id, authData.user.email || trimmedEmail);
            if (profile) {
              if (profile.isActive === false) {
                await supabase.auth.signOut();
                deleteCookie(ROLE_COOKIE_KEY);
                deleteCookie(AUTH_COOKIE_KEY);
                setUser(null);
                setRole(null);
                const deactMsg = 'Your account has been deactivated. Please contact the department.';
                setError(deactMsg);
                setIsLoading(false);
                return { success: false, error: deactMsg };
              }
              setUser(profile);
              setRole(profile.role);
              setCookie(ROLE_COOKIE_KEY, profile.role);
              setCookie(AUTH_COOKIE_KEY, 'true');
              setIsLoading(false);
              return { success: true, role: profile.role };
            }
          }

          // Auth succeeded but no profile found — shouldn't normally happen
          const noProfileMsg = 'Account authenticated but profile not found. Please contact the department.';
          setError(noProfileMsg);
          setIsLoading(false);
          return { success: false, error: noProfileMsg };
        }

        // Local demo fallback (only used when NEXT_PUBLIC_SUPABASE_URL is placeholder)
        const mockProfile = createMockProfile(trimmedEmail);
        setUser(mockProfile);
        setRole(mockProfile.role);
        setCookie(ROLE_COOKIE_KEY, mockProfile.role);
        setCookie(AUTH_COOKIE_KEY, 'true');
        setIsLoading(false);
        return { success: true, role: mockProfile.role };
      } catch (err: any) {
        const errMsg = err?.message || 'Unable to connect. Please check your internet connection.';
        console.error('Sign in error:', err);
        setError(errMsg);
        setIsLoading(false);
        return { success: false, error: errMsg };
      }
    },
    [fetchUserProfile]
  );

  const signOut = useCallback(async () => {
    setIsLoading(true);
    try {
      const supabase = getSupabaseBrowserClient();
      await supabase.auth.signOut();
    } catch (err) {
      console.warn('Sign out exception:', err);
    } finally {
      deleteCookie(ROLE_COOKIE_KEY);
      deleteCookie(AUTH_COOKIE_KEY);
      setUser(null);
      setRole(null);
      setIsLoading(false);
      router.push('/login');
    }
  }, [router]);

  const resetPassword = useCallback(async (email: string): Promise<{ success: boolean; message: string; devResetUrl?: string }> => {
    const origin = typeof window !== 'undefined' ? window.location.origin : '';
    try {
      const supabase = getSupabaseBrowserClient();
      const { error: resetErr } = await supabase.auth.resetPasswordForEmail(email.trim(), {
        redirectTo: `${origin}/auth/callback?type=recovery`,
      });

      if (resetErr) {
        return {
          success: false,
          message: resetErr.message || 'Failed to send password recovery email. Please verify your Supabase configuration.',
          devResetUrl: `${origin}/reset-password`,
        };
      }

      return {
        success: true,
        message: `Password reset instructions have been dispatched to ${email}. Please check your inbox and spam folder.`,
      };
    } catch (err: any) {
      console.error('Password reset exception:', err);
      const isFetchErr = err?.message === 'Failed to fetch' || err?.name === 'TypeError';
      return {
        success: false,
        message: isFetchErr
          ? 'Unable to connect to Supabase Auth service (unreachable or placeholder Supabase URL in .env.local). You can use the direct reset link below.'
          : err?.message || 'An unexpected error occurred while requesting password reset.',
        devResetUrl: `${origin}/reset-password`,
      };
    }
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        role,
        isLoading,
        isAuthenticated: Boolean(user && role),
        error,
        signIn,
        signOut,
        resetPassword,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuthContext() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuthContext must be used within an AuthProvider');
  }
  return context;
}
