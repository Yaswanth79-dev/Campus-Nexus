import { NextResponse, type NextRequest } from 'next/server';
import { updateSession } from './lib/supabase/middleware';
import { UserRole, normalizeRole } from './types/roles';

// Protected route prefixes mapping to required database roles
const ROLE_ROUTES: Record<string, UserRole> = {
  '/student': 'student',
  '/faculty': 'faculty',
  '/hod': 'hod',
};

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Let public assets, API routes, and static files pass
  if (
    pathname.startsWith('/_next') ||
    pathname.startsWith('/api') ||
    pathname.startsWith('/favicon.ico') ||
    pathname.includes('.')
  ) {
    return NextResponse.next();
  }

  // Check if current path matches any role-protected prefix
  const matchedPrefix = Object.keys(ROLE_ROUTES).find((prefix) =>
    pathname.startsWith(prefix)
  );

  // If path is not role-protected (e.g., /login, /unauthorized, /reset-password, /), refresh session and continue
  if (!matchedPrefix) {
    const { response } = await updateSession(request);
    return response;
  }

  const requiredRole = ROLE_ROUTES[matchedPrefix];

  // Check for active role and auth cookies
  const rawRoleCookie = request.cookies.get('campusnexus_active_role')?.value;
  const isAuthCookie = request.cookies.get('campusnexus_authenticated')?.value === 'true';

  // Also verify Supabase auth session
  const { response, user } = await updateSession(request);

  const isAuthenticated = Boolean(isAuthCookie || user);
  const activeRole = normalizeRole(rawRoleCookie) || normalizeRole(user?.user_metadata?.role);

  // If not authenticated or role missing, redirect to /login
  if (!isAuthenticated || !activeRole) {
    const loginUrl = new URL('/login', request.url);
    loginUrl.searchParams.set('redirect', pathname);
    return NextResponse.redirect(loginUrl);
  }

  // If authenticated but attempting to access another role's routes
  if (activeRole !== requiredRole) {
    const unauthorizedUrl = new URL('/unauthorized', request.url);
    unauthorizedUrl.searchParams.set('attempted', pathname);
    unauthorizedUrl.searchParams.set('requiredRole', requiredRole.toUpperCase());
    unauthorizedUrl.searchParams.set('currentRole', activeRole.toUpperCase());
    return NextResponse.redirect(unauthorizedUrl);
  }

  return response;
}

export const config = {
  matcher: [
    '/student/:path*',
    '/faculty/:path*',
    '/hod/:path*',
    '/login',
    '/reset-password',
    '/unauthorized',
  ],
};
